1) Create a .env file and add this line to it -> MONGODB_URL = mongodb+srv://comLab:comLab123@cluster0.mdfezgy.mongodb.net/comLabBooking?retryWrites=true&w=majority

2) Then goto mongoDBCompass and add this mongoDB server to it -> mongodb+srv://comLab:comLab123@cluster0.mdfezgy.mongodb.net/

3) Run this in CMD at BACKEND location -> 	npm install express mongoose dotenv cors nodemon

###IF you still get an error due to nodemon run this -> npm install -g nodemon

4) In cmd navigate to BACKEND folder and run this command (npm run dev )to see if the application is successfully connect to the mongoDB server.

Denata echcharai..... :)_ 
